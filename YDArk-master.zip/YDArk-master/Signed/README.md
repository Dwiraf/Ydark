# YOU MUST KNOW WHAT YOU ARE DOING  
  
'YDArkDrv-Signed.sys' has been signed with a compromised, expired certificate file.  
please chose one or more anti-virus software that you trust to check to ensure it's safe, before your using.  
this may strongly ** HARMFUL ** to your computer.  
this is only for testing.  
rename 'YDArkDrv-Signed.sys' to 'YDArkDrv.sys' and cover the 'YDArkDrv.sys' which haven't been signed, enjoy.  
  
  
***  
'YDArkDrv-Signed.sys' 使用一个泄露的、过期的证书进行了签名.  
使用本驱动前, 请先选择您信任的杀毒软件进行病毒查杀.  
使用本驱动可能会对您的电脑产生 ** 严重危害 ** , 除非您明白自己正在做什么, 否则请不要使用它.  
本驱动仅用于测试, 您不得将之用于非法用途或进行出售.  
使用本驱动造成的一切损害将由您自己负责.  
使用时重命名 'YDArkDrv-Signed.sys' 为 'YDArkDrv.sys', 并覆盖根目录未签名驱动, 重新启动主程序即可成功加载本驱动.  
本驱动已在windows7和windows10上测试可被成功加载.  
  
  
